<template>
    <TextboxComponent placeholder="Start"/>
</template>

<script>
import TextboxComponent from "../TextboxComponent.vue";

export default {
    components: {TextboxComponent},
    data() {
        return {
            start:"ssss"
        };
    },
}
</script>
