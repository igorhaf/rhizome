<template>
    <TextboxComponent placeholder="Schedule"/>
</template>

<script>
import TextboxComponent from "../TextboxComponent.vue";

export default {
    components: {TextboxComponent},
    data() {
        return {
            schedule:"ssss"
        };
    },
}
</script>
