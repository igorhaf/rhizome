<template>
    <TextboxComponent placeholder="Start time"/>
</template>

<script>
import TextboxComponent from "../TextboxComponent.vue";

export default {
    components: {TextboxComponent},
    data() {
        return {
            startTime:"ssss"
        };
    },
}
</script>
