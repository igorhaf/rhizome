<template>
    <TextboxComponent placeholder="Switch"/>
</template>

<script>
import TextboxComponent from "../TextboxComponent.vue";

export default {
    components: {TextboxComponent},
    data() {
        return {
            switchComponent:"ssss"
        };
    },
}
</script>
