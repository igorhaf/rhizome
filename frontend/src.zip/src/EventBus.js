/*EventBus*/
import mitt from 'mitt';

export const EventBus = mitt();
