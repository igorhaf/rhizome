import { NgModule } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatSidenavModule } from '@angular/material/sidenav';
import { Component } from '@angular/core';

@Component({
  selector: 'app-layout',
  template: `
    <div class="layout-container">
      <mat-toolbar color="primary" class="header">
        <span>My App</span>
      </mat-toolbar>

      <div class="content">
        <div class="sidebar-left">
          Left Sidebar
        </div>
        
        <div class="main-content">
          Main Content
        </div>
        
        <div class="sidebar-right">
          Right Sidebar
        </div>
      </div>

      <mat-toolbar class="footer">
        <span>Footer Content</span>
      </mat-toolbar>
    </div>
  `,
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent {}

@NgModule({
  imports: [
    // ...existing code...
    MatToolbarModule,
    MatGridListModule,
    MatSidenavModule
  ]
})
export class AppModule { }
